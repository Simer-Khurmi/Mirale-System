# IntelliHome AI — Advanced LLM + MQTT Smart Home (Demo)

**What you get**
- FastAPI backend with WebSocket real-time stream
- MQTT bridge to Mosquitto (docker-compose included)
- Advanced, multilingual (EN/FR) rule-first LLM parser with optional OpenAI enrichment
- Device registry with multiple devices & capabilities
- Frontend (vanilla HTML/CSS/JS) for parsing commands and viewing logs in real-time

## Quick Start (Docker, recommended)
```bash
cp .env.example .env
docker compose up --build
# Open http://localhost:8000
```

This starts Mosquitto on :1883 and the API+UI on :8000.

## Local Dev (without Docker)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export MQTT_BROKER_HOST=localhost
uvicorn src.backend.app:app --reload
```

## LLM Modes
- Default is **rule-based** parsing with bilingual support (EN/FR) and robust fallbacks.
- To enable OpenAI enrichment, set:
  - `LLM_PROVIDER=openai`
  - `OPENAI_API_KEY=sk-...`

The system will **never fail** if LLM is unavailable; it will revert to rule parsing and attach an ambiguity note.

## Topics
- Commands are published to `home/<room>/<device>/set/<action>`
- Status ingestion listens on `home/<room>/<device>/status`

## Extending
- Add devices in `src/backend/registry/registry.py`
- Add rules/lexicon in `src/backend/llm/engine.py`
- UI is static in `src/frontend/`

## Security Notes
- Demo Mosquitto allows anonymous access for local testing only.
- In production, configure TLS and authentication.
